(function(){const t=document.createElement("link").relList;if(t&&t.supports&&t.supports("modulepreload"))return;for(const n of document.querySelectorAll('link[rel="modulepreload"]'))o(n);new MutationObserver(n=>{for(const i of n)if(i.type==="childList")for(const c of i.addedNodes)c.tagName==="LINK"&&c.rel==="modulepreload"&&o(c)}).observe(document,{childList:!0,subtree:!0});function a(n){const i={};return n.integrity&&(i.integrity=n.integrity),n.referrerPolicy&&(i.referrerPolicy=n.referrerPolicy),n.crossOrigin==="use-credentials"?i.credentials="include":n.crossOrigin==="anonymous"?i.credentials="omit":i.credentials="same-origin",i}function o(n){if(n.ep)return;n.ep=!0;const i=a(n);fetch(n.href,i)}})();const k=[{id:"input-tools",name:"Input Tools",description:"コードブロック・絵文字・装飾タグの挿入、TO全選択"},{id:"mute-button",name:"Mute Button",description:"ワンクリックで通知をミュート"},{id:"quick-task",name:"Quick Task",description:"メッセージにmy taskボタンを追加"},{id:"mention-group",name:"Mention Group",description:"グループメンションをワンクリックで挿入"},{id:"reaction-copy",name:"Reaction Copy",description:"リアクションしたユーザー一覧をワンクリックでコピー"}],h=[{id:"info",label:"info",description:"infoタグで囲む",type:"tag",defaultEnabled:!0},{id:"title",label:"title",description:"titleタグで囲む",type:"tag",defaultEnabled:!0},{id:"code",label:"code",description:"codeタグで囲む",type:"tag",defaultEnabled:!0},{id:"hr",label:"hr",description:"hrタグを挿入",type:"tag",defaultEnabled:!0},{id:"bow",label:"🙇",description:"おじぎ (bow)",type:"emo",defaultEnabled:!0},{id:"roger",label:"👌",description:"了解 (roger)",type:"emo",defaultEnabled:!0},{id:"cracker",label:"🎉",description:"クラッカー (cracker)",type:"emo",defaultEnabled:!0},{id:"clap",label:"👏",description:"拍手 (clap)",type:"emo",defaultEnabled:!1},{id:"congrats",label:"㊗️",description:"おめでとう (congrats)",type:"emo",defaultEnabled:!1},{id:"love",label:"❤️",description:"ハート (love)",type:"emo",defaultEnabled:!1},{id:"to-all",label:"@all",description:"全員にTO",type:"action",defaultEnabled:!0}];function x(){return h.filter(e=>e.defaultEnabled).map(e=>e.id)}const d="plugin_";async function w(){const e=await chrome.storage.sync.get(null),t={};for(const[a,o]of Object.entries(e))a.startsWith(d)&&(t[a.replace(d,"")]=o);return t}async function E(e,t){const a=`${d}${e}`,o=(await chrome.storage.sync.get(a))[a]??{};await chrome.storage.sync.set({[a]:{...o,enabled:t}})}async function $(e,t){const a=`${d}${e}`,o=(await chrome.storage.sync.get(a))[a]??{};await chrome.storage.sync.set({[a]:{...o,apiKey:t}})}async function g(e){var o;const t=`${d}${e}`;return(o=(await chrome.storage.sync.get(t))[t])==null?void 0:o.config}async function b(e,t){const a=`${d}${e}`,o=(await chrome.storage.sync.get(a))[a]??{};await chrome.storage.sync.set({[a]:{...o,config:t}})}let y=null;function u(e){const t=document.getElementById("status");t&&(t.textContent=e,t.style.opacity="1",y&&clearTimeout(y),y=setTimeout(()=>{t.style.opacity="0"},2e3))}function I(e,t){const a=document.createElement("div");a.className="plugin-card";const o=(t==null?void 0:t.enabled)??!0;a.innerHTML=`
    <div class="plugin-info">
      <div class="plugin-name">${e.name}</div>
      <div class="plugin-description">${e.description}</div>
      ${e.requiresApiKey?`
        <div class="plugin-config">
          <label class="api-key-label">${e.apiKeyLabel??"API Key"}</label>
          <input type="password" class="api-key-input"
                 placeholder="APIキーを入力"
                 value="${(t==null?void 0:t.apiKey)??""}"
                 data-plugin-id="${e.id}">
        </div>
      `:""}
    </div>
    <label class="toggle">
      <input type="checkbox" ${o?"checked":""} data-plugin-id="${e.id}">
      <span class="toggle-slider"></span>
    </label>
  `;const n=a.querySelector('.toggle input[type="checkbox"]');if(n.addEventListener("change",async()=>{await E(e.id,n.checked),u(`${e.name} を${n.checked?"有効":"無効"}にしました`)}),e.requiresApiKey){const i=a.querySelector(".api-key-input");let c;i.addEventListener("input",()=>{clearTimeout(c),c=setTimeout(async()=>{await $(e.id,i.value),u("APIキーを保存しました")},500)})}return a}async function T(){const e=document.createElement("div");e.className="plugin-card";const t=await g("input-tools"),a=new Set((t==null?void 0:t.enabledButtons)??x());e.innerHTML=`
    <div class="plugin-info">
      <div class="plugin-name">Input Tools - ボタン設定</div>
      <div class="plugin-description">表示するボタンを選択</div>
      <div class="button-config" style="margin-top: 12px;"></div>
    </div>
  `;const o=e.querySelector(".button-config");for(const n of h){const i=document.createElement("label");i.className="button-config-item";const c=n.type==="tag"?"タグ":n.type==="emo"?"絵文字":"アクション";i.innerHTML=`
      <input type="checkbox" ${a.has(n.id)?"checked":""} data-button-id="${n.id}">
      <span class="button-config-label">${n.label}</span>
      <span class="button-config-desc">${n.description}</span>
      <span class="button-config-type">${c}</span>
    `;const s=i.querySelector("input");s.addEventListener("change",async()=>{s.checked?a.add(n.id):a.delete(n.id),await b("input-tools",{enabledButtons:Array.from(a)}),u("ボタン設定を保存しました")}),o.appendChild(i)}return e}async function L(){const e=document.createElement("div");e.className="plugin-card";const t=await g("quick-task"),a=(t==null?void 0:t.mode)??"mychat-url",o=(t==null?void 0:t.myChatId)??"",n=[{value:"mychat-url",label:"マイチャットにURLのみ"},{value:"mychat-message",label:"マイチャットにURL+メッセージ"},{value:"here-url",label:"現チャットにURLのみ (担当者=自分)"},{value:"here-message",label:"現チャットにURL+メッセージ (担当者=自分)"}];e.innerHTML=`
    <div class="plugin-info">
      <div class="plugin-name">Quick Task - 設定</div>
      <div class="plugin-description">タスク追加の動作モードとマイチャットID</div>
      <div style="margin-top: 12px;">
        <label class="api-key-label">動作モード</label>
        <select id="scw-task-mode" style="width: 100%; padding: 8px; border: 1px solid #ddd; border-radius: 6px; font-size: 13px; margin-top: 4px;">
          ${n.map(s=>`<option value="${s.value}" ${s.value===a?"selected":""}>${s.label}</option>`).join("")}
        </select>
      </div>
      <div style="margin-top: 12px;">
        <label class="api-key-label">マイチャットのルームID</label>
        <input type="text" id="scw-task-chatid" class="api-key-input"
               placeholder="例: 12345678"
               value="${o}">
      </div>
    </div>
  `,e.querySelector("#scw-task-mode").addEventListener("change",async s=>{const l=s.target.value,r=await g("quick-task")??{};await b("quick-task",{...r,mode:l}),u("Quick Taskモードを保存しました")});const i=e.querySelector("#scw-task-chatid");let c;return i.addEventListener("input",()=>{clearTimeout(c),c=setTimeout(async()=>{const s=await g("quick-task")??{};await b("quick-task",{...s,myChatId:i.value}),u("マイチャットIDを保存しました")},500)}),e}const f="quickMentionGroups";function v(e){const t=[],a=e.split(`
`).filter(o=>o.trim());for(const o of a){const n=o.match(/\[To:(\d+)\]\s*(.+?)(?:さん)?$/);if(n){t.some(c=>c.accountId===n[1])||t.push({accountId:n[1],name:n[2].trim()});continue}const i=o.split(/[,\t\s]+/);i.length>=2&&/^\d+$/.test(i[0])&&(t.some(c=>c.accountId===i[0])||t.push({accountId:i[0],name:i.slice(1).join(" ").trim()}))}return t}function q(e){return e.map(t=>`${t.accountId} ${t.name}`).join(`
`)}async function C(){const e=document.createElement("div");e.className="plugin-card",e.style.display="block";const a=(await chrome.storage.sync.get(f))[f]||[];e.innerHTML=`
    <div class="plugin-info">
      <div class="plugin-name">Mention Group - グループ管理</div>
      <div class="plugin-description">
        メンバーを1行ずつ入力（<code>accountId 名前</code> または <code>[To:accountId]名前さん</code> をコピペ）
      </div>
      <div id="scw-mg-group-list" style="margin-top: 12px;"></div>
      <div style="margin-top: 12px; display: flex; gap: 8px;">
        <button id="scw-mg-add" class="button-config-type" style="cursor: pointer; padding: 6px 12px; border: 1px solid #ddd; border-radius: 6px; background: #f8f8f8;">+ グループ追加</button>
        <button id="scw-mg-save" class="button-config-type" style="cursor: pointer; padding: 6px 12px; border: none; border-radius: 6px; background: #4a9eff; color: white;">保存</button>
      </div>
      <div id="scw-mg-status" style="margin-top: 8px; font-size: 12px;"></div>
    </div>
  `;const o=e.querySelector("#scw-mg-group-list");function n(i="",c=""){const s=document.createElement("div");s.style.cssText="border: 1px solid #eee; border-radius: 8px; padding: 12px; margin-bottom: 10px; background: #fafbfc;",s.innerHTML=`
      <div style="display: flex; align-items: center; gap: 8px; margin-bottom: 8px;">
        <input type="text" class="scw-mg-name api-key-input" placeholder="グループ名（例: 開発チーム）" value="${i}" style="flex: 1;">
        <button class="scw-mg-delete" style="border: none; background: none; color: #ccc; cursor: pointer; font-size: 18px; padding: 2px 6px;">&times;</button>
      </div>
      <textarea class="scw-mg-members api-key-input" placeholder="メンバーを1行ずつ入力&#10;例: 12345678 田中太郎&#10;または [To:12345678]田中太郎さん" style="width: 100%; min-height: 80px; font-family: monospace; font-size: 12px; line-height: 1.6; resize: vertical;">${c}</textarea>
      <div class="scw-mg-count" style="font-size: 11px; color: #888; margin-top: 4px; text-align: right;"></div>
    `;const l=s.querySelector(".scw-mg-members"),r=s.querySelector(".scw-mg-count"),p=()=>{const m=v(l.value).length;r.textContent=m>0?`${m}人`:""};return l.addEventListener("input",p),p(),s.querySelector(".scw-mg-delete").addEventListener("click",()=>{s.remove()}),s}if(a.length===0)o.appendChild(n());else for(const i of a)o.appendChild(n(i.name,q(i.members)));return e.querySelector("#scw-mg-add").addEventListener("click",()=>{o.appendChild(n())}),e.querySelector("#scw-mg-save").addEventListener("click",()=>{const i=o.querySelectorAll("div[style]"),c=[];i.forEach(s=>{const l=s.querySelector(".scw-mg-name"),r=s.querySelector(".scw-mg-members");if(!l||!r)return;const p=l.value.trim(),m=v(r.value);p&&m.length>0&&c.push({name:p,members:m})}),chrome.storage.sync.set({[f]:c},()=>{const s=c.reduce((l,r)=>l+r.members.length,0);u(`${c.length}グループ（計${s}人）を保存しました`)})}),e}async function S(){const e=document.getElementById("plugin-list");if(!e)return;const t=await w();for(const a of k){const o=I(a,t[a.id]);if(e.appendChild(o),a.id==="input-tools"){const n=await T();e.appendChild(n)}if(a.id==="quick-task"){const n=await L();e.appendChild(n)}if(a.id==="mention-group"){const n=await C();e.appendChild(n)}}}S();
